
import pygame
from pygame.locals import *
import sys
import random

class CORLOR:
    def __init__(self):
        self.WHITE = (255,255,255)
        self.BLACK = (0,0,0)
        self.RED = (255, 0, 0)
        self.BLUE = (0, 0, 255)
        self.GREEN = (0, 255, 0)

class Game_map:
    def __init__(self):
        self.CORLOR = CORLOR()
    
    def draw_lines(self):
        pass

class People(pygame.sprite.Sprite):
    def __init__(self,up_speed = 6,down_speed = 4):
        pygame.sprite.Sprite.__init__(self) # Call the parent class (Sprite) constructor
        self.up_speed = up_speed #speed of people going up
        self.down_speed= down_speed
        self.image = Point((0,0),(12,12),[1,1,23,23])
        self.rect= self.image.rect #position
        self.rect.top=0
        self.rect.left=0
        self.corlor = Color(0,0,0)
        self.pid = [0,0]

    def move_left(self):
        self.pid[0] -= 1
        self.rect.left -= 24
    
    def move_up(self):
        if self.rect.top > 0:
            self.pid[1] -= 1
            self.rect.top -= 24
    
    def move_down(self):
        if self.rect.top != 552 + 24:
            self.pid[1] += 1
            self.rect.top += 24
    
    def move_right(self):
        self.pid[0] += 1
        self.rect.left += 24

    def restart(self):
        self.pid = [0,0]
        self.rect.top = 0
        self.rect.left = 0


class Point:
    def __init__(self,pid,pos,rect):
        self.pid = pid
        self.pos = pos
        self.rect = Rect(rect)
        self.state = 0

class Life_game:
    def __init__(self):
        self.point = self.map_maker()
        self.life_time = 3
        #print(self.point)
    
    def get_around_point_state(self,current_point):
        x_index = current_point[0]
        y_index = current_point[1]
        top_side_point_1 = self.get_point([x_index - 1 ,y_index - 1])
        top_side_point_2 = self.get_point([x_index     ,y_index - 1])
        top_side_point_3 = self.get_point([x_index + 1 ,y_index - 1])
        left_side_point  = self.get_point([x_index - 1 ,y_index    ])
        right_side_point = self.get_point([x_index + 1 ,y_index    ])
        bottom_side_point_1 = self.get_point([x_index - 1 ,y_index + 1])
        bottom_side_point_2 = self.get_point([x_index     ,y_index + 1])
        bottom_side_point_3 = self.get_point([x_index + 1 ,y_index + 1])
        alive_count = 0
        for point in [top_side_point_1,top_side_point_2,top_side_point_3,left_side_point,right_side_point,bottom_side_point_1,bottom_side_point_2,bottom_side_point_3]:
            if point:
                if point.state == 1:
                    alive_count += 1
        return alive_count

    def map_maker(self):
        pos = []
        x = 12
        y = 12
        rect_x = 0
        rect_y = 0
        for i in range(30):
            temp_pos = []
            for j in range(25):
                # rect_one_point = (x - 15,y - 15)
                # rect_two_point = (x + 15,y + 15)
                temp_pos.append(Point([i,j],[x,y],[rect_x + 1,rect_y + 1,23,23]))
                rect_y += 24
                x += 12
            x = 12
            rect_y = 0
            y += 12
            rect_x += 24
            pos.append(temp_pos)
        return pos

    def random_point(self,current_pos,number = 5):
        new_x_list = []
        for i in range(30):
            if i != current_pos[0] and i != 29:
                new_x_list.append(i)
        new_y_list = []
        for i in range(25):
            if i != current_pos[1] and i != 24:
                new_y_list.append(i)
        
        count = 0
        while count < number:
            while True:
                x = random.choice(new_x_list)
                y = random.choice(new_y_list)
                if self.point[x][y].state == 1:
                    pass
                else:
                    self.point[x][y].state = 1
                    count += 1
                    break

    def get_point(self,index_list):
        try:
            if -1 in index_list:
                return None
            return self.point[index_list[0]][index_list[1]]
        except BaseException as e:
            return None

    def update_point(self,index_list):
        if self.point[index_list[0]][index_list[1]].state == 1:
            print("current point has been alive")
        else:
            self.point[index_list[0]][index_list[1]].state = 1

    def life_loop(self):
        should_change_point = self.get_need_change_point()
        self.set_change_point(should_change_point)

    def get_need_change_point(self):
        should_change_point = []
        for line in self.point:
            for point in line:
                around_alive = self.get_around_point_state(point.pid)
                if around_alive == 3:
                    should_change_point.append((point,3,point.state))
                elif around_alive == 2:
                    pass
                else:
                    should_change_point.append((point,0))
        return should_change_point

    def set_change_point(self,point_list):
        should_change_point = point_list
        for point in should_change_point:
            if point[1] == 3:
                point[0].state = 1
            else:
                if point[1] == 0:        
                    point[0].state = 0

    
    def restart(self):
        for line in self.point:
            for point in line:
                point.state = 0


def click_point_change(pos):
    right_x_index = 0
    right_y_index = 0
    if pos[0] <= 24:
        right_x_index = 0
    else:
        right_x_index = (pos[0] // 24)
    if pos[1] <= 24:
        right_y_index = 0
    else:
        right_y_index = (pos[1] // 24)
    return [right_x_index,right_y_index]
    

width = 720
height = 600
size = width, height
pygame.init()
screen = pygame.display.set_mode(size)
game_corlor = CORLOR()
life_game = Life_game()
clock = pygame.time.Clock()
people = People()
life_time = 0
should_change_point = []
key_press_time = 0
bling_time = 0
bling_show = True
should_change_point = life_game.get_need_change_point()


## 

random_point_num = 10
life_game.life_time = life_game.life_time
setp_random_point = 5


def hit_cheak(point):
    if life_game.get_point(point.pid).state == 1:
        return True
    else:
        return False

def set_init_random():
    start_around = []
    for i in range(3):
        for j in range(3):
            start_around.append([i,j])
    end_around = []
    for i in range(3):
        for j in range(3):
            end_around.append([29 - i, 24 -j]) 
    for i in life_game.point:
        for point in i:
            if random.randint(1,3) == 1 and point.pid not in (start_around + end_around):
                point.state = 1




class Curor:
    def __init__(self):
        self.rect = Rect(110,110,20,20)
        self.current_choose = 0

    def move_up(self):
        if self.current_choose - 1 == -1:
            self.current_choose = 2
            self.rect.top = 210
        else:
            self.current_choose -= 1
            self.rect.top -= 50
    
    def move_down(self):
        if self.current_choose + 1 == 5:
            self.current_choose = 0
            self.rect.top = 110
        else:
            self.current_choose += 1
            self.rect.top += 50

top_title = "start"

run = False
curor = Curor()

while True:
    for event in pygame.event.get():
        # 查找关闭窗口事件
        if event.type == QUIT:
            sys.exit()
        if run == False:
            if event.type == 2:
                if event.key == 273:
                    curor.move_up()
                if event.key == 274:
                    curor.move_down()
                if event.key == 13:
                    
                    choose = curor.current_choose
                    print(choose)
                    if choose == 3:
                        if top_title == "stop":
                            run = True
                            curor.current_choose = 0
                            curor.rect.top = 110
                        else:
                            sys.exit()
                    else:
                        if choose == 0:
                            random_point_num = 15
                            life_game.life_time = 2
                            setp_random_point = 8
                        elif choose == 1:
                            random_point_num = 20
                            life_game.life_time = 1
                            setp_random_point = 10
                        elif choose == 2:
                            random_point_num = 40
                            life_game.life_time = 0.4
                            setp_random_point = 20
                        elif choose == 4:
                            sys.exit()
                        life_game.restart()
                        people.restart()
                        set_init_random()
                        curor.current_choose = 0
                        curor.rect.top = 110
                        run = True
                        
        else:
            if event.type == 2:
                if event.key == 32:
                    life_game.life_loop()
                if event.key == 273:
                    key_press_time = 0
                    life_game.random_point(people.pid,setp_random_point)
                    people.move_up()
                if event.key == 274:
                    key_press_time = 0
                    life_game.random_point(people.pid,setp_random_point)
                    people.move_down()
                if event.key == 276:
                    key_press_time = 0
                    life_game.random_point(people.pid,setp_random_point)
                    people.move_left()
                if event.key == 275:
                    key_press_time = 0
                    life_game.random_point(people.pid,setp_random_point)
                    people.move_right()
                if event.key == 27:
                    run = False
                    top_title = "stop"
    
    display_window = pygame.Surface((400,400))
    display_window.fill((0,0,0))
    font1 = pygame.font.SysFont('Time', 30)
    font2 = pygame.font.SysFont('Time', 25)
    title_ = font1.render(top_title,True,(255,255,255))
    easy_ = font2.render("easy mode",True,(255,255,255))
    mid_ = font2.render("mid mode",True,(255,255,255))
    hard_ = font2.render("hard mode",True,(255,255,255))
    continue_ = font2.render("continue",True,(255,255,255))
    quit_ = font2.render("QUIT",True,(255,255,255))
    can_choose = [0,1,2]
    current_choose = can_choose[0]
    choose_pos = Rect(110,110,20,20)
    display_window.blit(title_,(150,10))
    display_window.blit(easy_,(150,110))
    display_window.blit(mid_,(150,160))
    display_window.blit(hard_,(150,210))
    if top_title == "stop":
        display_window.blit(continue_,(150,260))
        display_window.blit(quit_,(150,310))
    else:
        display_window.blit(quit_,(150,260))
    screen.fill(game_corlor.WHITE)
    pygame.draw.rect(display_window,(255,255,0),curor.rect)

    y = 0
    for i in range(25):
        pygame.draw.line(screen,game_corlor.BLUE , (0, y), (720, y), 1)
        y += 24
    x = 0
    for i in range(30):
        pygame.draw.line(screen,game_corlor.BLUE , (x, 0), (x,600), 1)
        x += 24

    for line in life_game.point:
        for point in line:
            if point.state == 1:
                pygame.draw.rect(screen,game_corlor.RED,point.rect)

    
    if run == True:
        time_passed = clock.tick()
        time_passed_second = time_passed / 1000 
        key_press_time += time_passed_second
        bling_time += time_passed_second

        

        life_time += time_passed_second 
        if life_time >= life_game.life_time:
            life_game.life_loop()
            bling_show = True
            should_change_point = life_game.get_need_change_point()
            life_time = 0
        for point in should_change_point:
            if point[1] == 3 and point[2] == 0:
                if bling_time < 0.7 and bling_show:
                    #s = (random.randint(0,255),random.randint(0,255),random.randint(0,255))
                    pygame.draw.rect(screen,game_corlor.BLUE,point[0].rect)
                else:
                    bling_time = 0
                    bling_show = False
        if key_press_time >= life_game.life_time * 2:
            life_game.random_point(people.pid,random_point_num)
            key_press_time = 0

        pygame.draw.rect(screen,people.corlor,people.rect)

        if hit_cheak(people):
            run = False
            top_title = "you fail!"
    if run == False:
        screen.blit(display_window,(160,100))
    pygame.display.flip()
